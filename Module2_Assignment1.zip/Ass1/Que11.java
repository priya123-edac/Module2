//Q11.WAP to swap two numbers without using third variable
package Ass1;
import java.util.Scanner;
public class Que11
{
    public  static void main(String args[])
    {
        System.out.println("Enter two values to be swapped!!");
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        int y=sc.nextInt();
        System.out.println("Before swap values:"+" "+"x="+x+" "+"y="+y);//x=5 y=10
        x=x*y;//x becomes 50
        y=x/y;//y becomes 10
        x=x/y;//x becomes 5
      System.out.println("After swap values:"+" "+"x="+x+" "+"y="+y);

        
    }
}
