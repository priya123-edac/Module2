/*WAP to calculate sum of 5 subject's marks & find percentage.Take the obtained marks from user
using scanner class.Output should be in this format[percentage marks=99%].Use concatenation 
operator here.
*/
package Ass1;
import java.util.Scanner;
public class Que7
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number of subjects:");
        int n=sc.nextInt();
        
         //System.out.println("Enter total number of marks:");
        //int total=sc.nextInt();
        float marks[]=new float[n];
        System.out.println("Enter marks  of all subjects:");
      double sum=0,percentage;
       for(int i=0;i<marks.length-1;i++)
       {
          marks[i]=sc.nextFloat();
           sum=sum+marks[i];
           
       }
       System.out.println("Sum is:"+sum);
       
       percentage=sum/n;
       System.out.println("Percentage is:"+percentage);
        
    }
}

