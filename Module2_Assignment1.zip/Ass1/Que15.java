/*Accept person's gender (character m for male and f for female),age(integer) as input and then check whether person 
is eligible for marriage or not.*/
package Ass1;
import java.util.Scanner;
public class Que15
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter character m for male and f for female:");
        char gender=sc.next().charAt(0);
        System.out.println("Enter the age:");
        int age=sc.nextInt();
       
        if((gender=='f') && (age>=18))
        {
            System.out.println("This female candidate is elegible for marriage!!"); 
        }
            else if((gender=='f') && (age<18))
            {
                     System.out.println("This female candidate is not elegible for marriage!!");
             }
        
        else if((gender=='m') && (age>=22))
        {
            System.out.println("This male candidate is elegible for marriage!!");
        }
         else if((gender=='m') && (age<22))
        {
            System.out.println("This male candidate is not elegible for marriage!!");
        }
        
        
    }
}