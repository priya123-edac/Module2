/*2.Write a program which takes an array of integers and prints the running average of 3 consecutive
integers. In case the array has fewer than 3 integers, there should be no output.
Input: [5,14,35,89,140]
Output: [18, 46, 88]
(Explanation: 18=(5+14+35/3, 46=(14+35+89)/3, ...)
*/
package Ass4;
import java.util.Scanner;
public class Que2
{
    Scanner sc=new Scanner(System.in);
    int n;
    int arr[];
    int temp[];
    int l,sum=0;
    
    void setData()
    {
        System.out.println("Enter the array size:");
        n=sc.nextInt();
        arr=new int[n];
        System.out.println("ENter array elements:");
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=sc.nextInt();
        }
    }
    
    void logic()
    {
        l=n-2;
        temp=new int[l];
        for(int i=0;i<l;i++)
        {
            sum=0;
            if(i<l)
            {
                sum=arr[i]+arr[i+1]+arr[i+2];
                sum=sum/l;
                temp[i]=sum;
            }
           }
        System.out.println("Output");
        for(int i=0;i<temp.length;i++)
        {
            System.out.println(temp[i]);
        }
    }
    public static void main(String args[])
    {
       Que2 q=new Que2();
       q.setData();
       q.logic();
    }
}