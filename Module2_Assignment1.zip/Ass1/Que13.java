/*WAP to find greatest in three numbers [once using if else statement and once using
terneray operator(logical operator)*/
package Ass1;
import java.util.Scanner;
public class Que13
{
      //Using if-else loop
    
       /* public static void main(String args[])
        {
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter the three numbers:");
         int n1=sc.nextInt();
         int n2=sc.nextInt();
         int n3=sc.nextInt();
         
         if((n1>n2) && (n1>n3))
         {
             System.out.println("n1 is greater!!");
         }
         else if((n2>n1) && (n2>n3))
         {
             System.out.println(n2+" "+"is greater!!");
             
         }
         else if((n3>n1) && (n3>n2))
         {
             System.out.println(n2+"  "+"is greater!!!");
         }
         else
         {
             System.out.println(n3+" "+"All are equal!!");
         }
        }*/
    
    //Using ternary operator
    
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
         System.out.println("Enter the three numbers:");
         int a=sc.nextInt();
         int b=sc.nextInt();
         int c=sc.nextInt();
         
int  d = c > (a > b ? a : b) ? c : ((a > b) ? a : b);  
System.out.println("Largest Number:"+d);
    }


}