/*Q5.WAP that takes user's name as command line argument and prints Welcome<entered user name*/
package Ass1;
import java.util.Scanner;
public class Que5
{
public static void main(String []args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter your name:");
String name=sc.nextLine();
System.out.println("Welcome"+" "+name);


}

}