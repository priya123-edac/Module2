/** /**In a company an employee is paid as under:If his basic salary is less than Rs.10000,then 
 * HRA=10% of basic salary and DA=90% of basic salary.If his salary is equal to or above 10,000 then
 * HRA=2000 and DA=98% of basic salary. If the employee's salary is input by the user write a program 
 * to find his gross salary.[Formula GS=Basic +DA + HRA] **/

package Ass1;
import java.util.Scanner;
public class Que12
{
    public static void main(String args[])
    {
        int HRA,DA,GS=0;
     Scanner sc=new Scanner(System.in);
     int salaryBs=sc.nextInt();
     sc.close();
     if(salaryBs<10000)
     {
         HRA=(10*salaryBs)/100;
         DA=(90*salaryBs)/100;
         GS=salaryBs+DA+HRA;
         System.out.println("Gross salary is:"+GS);
     }
     else if(salaryBs>=10000)
     {
         HRA=2000;
         DA=(90*salaryBs)/100;
         GS=salaryBs+DA+HRA;
         System.out.println("Gross salary is:"+GS);
     }
    }
}