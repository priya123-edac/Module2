/**Q3.Find the result of following expressions.You need to determine the primitive data type of the
variable by looking carefully the given expression and initialize variables by any random value.
A. y=x^2 +3x -7(print value of y)
B. y=x++ + ++x(print value of x and y)
C. z=x&&y || !(x||y) (print value of z) [x,y,z are boolean variable]
**/
package Ass1;
public class Que3
{
    public static void main(String []args)
    {
        int x=5;
        int y=(x*x +3*x-7);
        System.out.println("Value of y:"+y);
        y=x++ + ++x;
       System.out.println("x="+x+" "+"y="+y);  
       boolean X=false,Y=false;
       boolean Z;
       Z=((X&&Y) || !(X||Y));
       System.out.println("Value of z:"+Z);
       
         
    }
}
