//To reverse a given number and print it.
package Ass2;
import java.util.Scanner;
public class Que2
{
    public static void main(String args[])
    {
        int digit;
        int rev=0;
        System.out.println("Enter a number:");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
       
        while(n!=0)
        {
        digit=n%10;
        rev=rev*10 +digit;
        n/=10;
        }
    
    System.out.println("Reverse number:"+rev);
     }
}