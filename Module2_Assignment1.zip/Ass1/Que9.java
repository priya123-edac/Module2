/* WAP to read the days as integer value using Scanner class. Now convert the entered days
into complete years,monthsand days and print them*/
package Ass1;
import java.util.Scanner;
public class Que9
{
    //One way to do this code:
   /* public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number of days:");
        int Usday=sc.nextInt(); //500
        //calculate number of years
        int year=Usday/365; //year=500/365
        Usday=Usday%365;
        //calculate number of months
       int month=Usday/12;
       Usday=Usday%12;
       //calculate number of days
       int day=Usday;
       System.out.println("The given number has:"+" "+year+"years"+","+month+" "+"months"+" "+"and"+" "+Usday+"days!!!");
   }*/
    
    
    //2nd way to do the same coe:
    public static void main(String args[])
    {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter number of days:");
     int ndays=sc.nextInt();
     //calculate year
     int year=ndays/365;
     ndays=ndays-(365*year);
     
     //calculate month
     int month=ndays/30;
     
     //calculate days
     int day=ndays-(month*30);
     	System.out.println(" Year(s):"+" "+year +"\n"+" Month(s):"+month+" "+"\n"+"Day(s):"+day);

           
    }
}