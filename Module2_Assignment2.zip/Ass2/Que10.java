package Ass2;
import java.util.Scanner;
public class Que10
{
    public static void main(String args[])
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the number of array elements you want to enter:");
       int n=sc.nextInt();
       int arr[]=new int[n];
       int even=0,odd=0;
       System.out.println("Enter the array elements:");
       for(int i=0;i<=arr.length-1;i++)
       {
         arr[i]=sc.nextInt();  
       }
       for(int i=0;i<=arr.length-1;i++)
       {
         if(arr[i]%2==0)
         {
            
             even=even+arr[i];
             
         }
         else 
         {
         
             odd=odd+arr[i];
            
         }
      }
       System.out.println("Sum of even elements is:"+even);
      System.out.println("Sum of odd elements is:"+odd);
    }
}