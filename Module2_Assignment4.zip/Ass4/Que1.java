/*1. Write a program to merge two arrays of integers by reading one number at a time from each array
until one of the array is exhausted, and then concatenating the remaining numbers.
Input: [23,60,94,3,102] and [42,16,74]
Output: [23,42,60,16,94,74,3,102]
*/
package Ass4;
import java.util.*;
public class Que1
{
    public static void main(String args[])
    {
       //Declarations
        int arr[]={23,60,94,3,102};
        int arr1[]={42,16,74};
        int alength=arr.length;
        int blength=arr1.length;
        int result[]=new int[alength+blength];
        int j=0,k=0,l=0;
        System.out.println("Before merge:");
       System.out.println("Array 1:");
        {
        for(int i=0;i<alength;i++)
        System.out.println(arr[i]);
        }
        System.out.println("Array2:");
        for(int i=0;i<blength;i++)
        {
        System.out.println(arr1[i]);
        }
        while(j<alength && k<blength)
        {
          
            result[l++]=arr1[k++];
            
        }
        
        while(j<alength)
        {
            result[l++]=arr[j++];
        }
        while(j<blength)
        {
            result[l++]=arr1[k++];
        }
        System.out.println("After merge:");
        for(int i=0;i<alength+blength;i++)
        {
            
            System.out.print(result[i]+ " ");
        }
      
       
       
       
        
        
            
       
    }
}