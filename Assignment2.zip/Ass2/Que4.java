//To print a prime numbers in a given range!!
package Ass2;
import java.util.Scanner;
public class Que4
{
    public static void main(String args[])
    {
        //initialize and declare here
        int s1,s2,count=0,i,j;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the lower limit:");
        s1=sc.nextInt();
        System.out.println("Enter the upper limit:");
        s2=sc.nextInt();
        for(i=s1;i<=s2;i++)
        {
            for(j=2;j<i;j++)
            {
                if(i%j==0)
                {
                    count=0;
                    break;
                    
                }
                else
                {
                    count=1;
                }
            }
           
            if(count==1)
            {
                
             System.out.println(i);
            }
        }
    }
}