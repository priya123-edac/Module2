/*WAP to convert temperature from fahrenheit to celsius. Take fahrenheit as input 
using Scanner class. Formula:C=5*(f-32/9]*/
package Ass1;
import java.util.Scanner;

public class Que10
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the tem. in Fahrenheit:");
       double te=sc.nextDouble();
       double  celsius =(( 5 *(te - 32.0)) / 9.0);

      //double  celsius = (te-32)*(0.5556);
       System.out.println("Temperature in celsius is:"+celsius);
       
 }
}
