/*WAP to find Simple Interest.Take the principle amount,rate of interest and time from user 
using Scanner class*/
package Ass1;
import java.util.Scanner;
public class Que8
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter prin. amount,rate of interest and time to calculate Simple Inteest:");
        int Pa=sc.nextInt();
        float ri=sc.nextFloat();
        int time=sc.nextInt();
        //Simple Interest is P x r x t ÷ 100, where P=Principal Amount, Rate of Interest & T= Time.
        float Simp_Interest=(Pa*ri*time)/100;
        System.out.println("Simple interest is:"+Simp_Interest);
        
        
        
        sc.close();
    }
}