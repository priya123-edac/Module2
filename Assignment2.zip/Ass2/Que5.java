//To print the sum and average of array elements
package Ass2;
import java.util.Scanner;

public class Que5
{
    public static void main(String Args[])
    {
        int n,sum=0;
        float average;
        Scanner sc=new Scanner(System.in);
        System.out.println("ENter the array elements:");
        System.out.println("=============================");
        n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
            sum=sum+a[i]; 
        }
    System.out.println("sum is:"+sum);
    average =(float)sum/n;
    System.out.println("Average is:"+average);
    }
}