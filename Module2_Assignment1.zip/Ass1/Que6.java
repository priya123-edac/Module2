/*Q6.WAP that takes radius of a circle as input.Read the entered radius using scanner class. Then
calculate and print the area and circumference of the circle.*/
package Ass1;
import java.util.Scanner;
public class Que6
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the radius value:");
        double r=sc.nextDouble();
        sc.close();
        double area,circ;
        area=3.14*r*r;
        circ=2*3.14*r;
        System.out.println("Area is:"+area+" "+"Circumference is :"+circ);
        
        
        
        
    }
}