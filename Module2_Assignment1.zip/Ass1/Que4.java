/*Q4.WAP that initializes 2 byte type of variables. Add the values of these variables and 
store in a byte type of variable.
[Note: Primitive down casting is required in this program.] */
package Ass1;
public class Que4
{
    public static void main(String []args)
    {
        byte a=12;
        byte b=74;
        byte result;
        result=(byte)(a+b);
        System.out.println(result);
        
    }
}
