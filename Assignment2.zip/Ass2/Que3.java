//To print wether a given number is prime or not!!
package Ass2;
import java.util.Scanner;
public class Que3
{
    public static void main(String args[])
    {
        int temp;
        boolean flag=true;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number:");
        int num=sc.nextInt();
        sc.close();
        
        for(int i=2;i<=num/2;i++)
        {
            temp=num%i;
            if(temp==0)
            {
             flag=false;
             break;
            }
            
        }
        if(!flag)
            System.out.println(num+" is a prime number!!");
        else
        System.out.println(num+"is not a prime number!!");
        
    }
}