//Q1.Write a program to print a Hello World. Compile and run it using command prompt.
package Ass1;
public class Que1
        {
public static void main(String []args)
{
System.out.println("Hello World!!");
}
}