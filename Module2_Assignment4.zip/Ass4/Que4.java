/*4.Given an array of integers, print whether the numbers are in ascending order or in descending
order or in random order without sorting
Input: [5,14,35,90,139] Output: Ascending
Input: [88,67,35,14,-12] Output: Descending
Input: [65,14,129,34,7] Output: Random
*/
package Ass4;
import java.util.Scanner;
public class Que4
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("ENter array elements:");
        int n=sc.nextInt();
        int a[]=new int[n];
         int count=0;
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
                System.out.println("Entered array is:");

        for(int i=0;i<n;i++)
                {
                    System.out.println(a[i]+" ");
                }
         for(int i=0;i<a.length;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[i]<=a[j])
                {
                    count++;
                }
            }
        }
            int temp=0;
       
       for(int i=0;i<a.length;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[j]<a[i])
                {
                    temp++;
                }
            }
        }
            if(count==(n*2))
            {
                System.out.println("Ascending!!");
                 }
            else if(temp==(n*2))
            {
               System.out.println("Descending!!"); 
              
            }
            else
            {
                System.out.println("Random!!");
                
            }
       
        }
    }
