//Que4. To calculate series...12+22+32+42+....+n2
package Ass2;

public class Que9
{
    public static void main(String args[])
    {
      int i=12,sum=0;
    while(i<=102)
        {
            System.out.print(i);
           
            System.out.print("+");
            sum=sum+i;
            i+=10;
            
            
        }
        System.out.println("\nSum is:"+sum);
        
    }
}

