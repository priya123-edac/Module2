/*Q2.Write a program to declare a variable named rollNo of integer type. Assign a value to it 
(say 100) and print the following statement roll no=100.*/

package Ass1;
public class Que2
{
    public static void main(String []args)
    {
       int rollNo=100;
       System.out.println("roll no:"+rollNo);
    }
}